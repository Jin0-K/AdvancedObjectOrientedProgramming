import java.io.File;

public interface Preprocessor {
    SourceCode preprocess(SourceCode source_code);
}
