
public interface Compiler {
    ObjectCode compile(SourceCode source_code);
}
