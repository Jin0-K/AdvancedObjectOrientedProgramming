public class SourceCode {
    private String file_name;

    // Constructor
    public SourceCode(String file_name) {
        this.file_name = file_name;
    }

    // Methods
    String getFileName() {
        return file_name;
    }
}
