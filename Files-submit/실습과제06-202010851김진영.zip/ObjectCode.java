public class ObjectCode {
    private String file_name;

    // Constructor
    public ObjectCode(String file_name) {
        this.file_name = file_name;
    }

    // Methods
    String getFileName() {
        return file_name;
    }
}
