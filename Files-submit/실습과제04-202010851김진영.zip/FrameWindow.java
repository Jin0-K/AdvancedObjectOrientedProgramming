import javax.swing.JPanel;

public abstract class FrameWindow {

    public abstract JPanel createPanel(int width, int height);
}
